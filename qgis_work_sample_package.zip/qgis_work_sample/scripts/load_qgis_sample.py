import os
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsFillSymbol,
    QgsLineSymbol,
    QgsMarkerSymbol,
    QgsPalLayerSettings,
    QgsTextFormat,
    QgsVectorLayerSimpleLabeling
)
from qgis.PyQt.QtGui import QColor, QFont


def load_layer(path, name):
    layer = QgsVectorLayer(path, name, "ogr")
    if not layer.isValid():
        raise RuntimeError("Failed to load layer: {}".format(path))
    QgsProject.instance().addMapLayer(layer)
    return layer


script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)
data_dir = os.path.join(project_root, "data")

layer_paths = {
    "study_area": os.path.join(data_dir, "study_area.geojson"),
    "neighborhoods": os.path.join(data_dir, "neighborhoods.geojson"),
    "roads": os.path.join(data_dir, "roads.geojson"),
    "bus_route": os.path.join(data_dir, "bus_route.geojson"),
    "bus_stops": os.path.join(data_dir, "bus_stops.geojson"),
    "schools": os.path.join(data_dir, "schools.geojson"),
    "clinics": os.path.join(data_dir, "clinics.geojson"),
    "parks": os.path.join(data_dir, "parks.geojson"),
    "service_buffers": os.path.join(data_dir, "service_buffers.geojson"),
    "transit_buffers": os.path.join(data_dir, "transit_buffers.geojson"),
    "priority_gap": os.path.join(data_dir, "priority_gap.geojson"),
}

project = QgsProject.instance()

study_area = load_layer(layer_paths["study_area"], "Study Area")
neighborhoods = load_layer(layer_paths["neighborhoods"], "Neighborhoods")
roads = load_layer(layer_paths["roads"], "Roads")
bus_route = load_layer(layer_paths["bus_route"], "Bus Route")
bus_stops = load_layer(layer_paths["bus_stops"], "Bus Stops")
schools = load_layer(layer_paths["schools"], "Schools")
clinics = load_layer(layer_paths["clinics"], "Clinics")
parks = load_layer(layer_paths["parks"], "Parks")
service_buffers = load_layer(layer_paths["service_buffers"], "Service Buffers")
transit_buffers = load_layer(layer_paths["transit_buffers"], "Transit Buffers")
priority_gap = load_layer(layer_paths["priority_gap"], "Priority Gap")

# Polygon styles
study_area.renderer().setSymbol(QgsFillSymbol.createSimple({
    "color": "255,255,255,0",
    "outline_color": "0,0,0,255",
    "outline_width": "0.8"
}))

neighborhoods.renderer().setSymbol(QgsFillSymbol.createSimple({
    "color": "244,114,76,110",
    "outline_color": "90,90,90,180",
    "outline_width": "0.35"
}))

parks.renderer().setSymbol(QgsFillSymbol.createSimple({
    "color": "190,232,198,180",
    "outline_color": "72,134,82,220",
    "outline_width": "0.3"
}))

service_buffers.renderer().setSymbol(QgsFillSymbol.createSimple({
    "color": "121,198,255,45",
    "outline_color": "55,151,211,130",
    "outline_width": "0.25"
}))

transit_buffers.renderer().setSymbol(QgsFillSymbol.createSimple({
    "color": "201,160,255,28",
    "outline_color": "125,75,204,120",
    "outline_width": "0.2"
}))

priority_gap.renderer().setSymbol(QgsFillSymbol.createSimple({
    "color": "255,77,77,70",
    "outline_color": "209,47,47,180",
    "outline_width": "0.45"
}))

# Line styles
roads.renderer().setSymbol(QgsLineSymbol.createSimple({
    "line_color": "110,110,110,200",
    "line_width": "0.35"
}))

bus_route.renderer().setSymbol(QgsLineSymbol.createSimple({
    "line_color": "32,102,209,255",
    "line_style": "dash",
    "line_width": "0.9"
}))

# Point styles
schools.renderer().setSymbol(QgsMarkerSymbol.createSimple({
    "name": "triangle",
    "color": "28,124,47,255",
    "outline_color": "255,255,255,255",
    "size": "4.2"
}))

clinics.renderer().setSymbol(QgsMarkerSymbol.createSimple({
    "name": "square",
    "color": "162,58,44,255",
    "outline_color": "255,255,255,255",
    "size": "4.0"
}))

bus_stops.renderer().setSymbol(QgsMarkerSymbol.createSimple({
    "name": "circle",
    "color": "95,61,196,255",
    "outline_color": "255,255,255,255",
    "size": "3.0"
}))

# Neighborhood labels
label_settings = QgsPalLayerSettings()
label_settings.fieldName = "\"name\" || '\nGap ' || round(\"gap_pct\", 1) || '%'"
label_settings.isExpression = True

text_format = QgsTextFormat()
text_format.setFont(QFont("Arial", 10))
text_format.setSize(10)
text_format.setColor(QColor(20, 20, 20))
text_format.setBufferEnabled(True)
text_format.buffer().setEnabled(True)
text_format.buffer().setSize(1.0)
text_format.buffer().setColor(QColor(255, 255, 255))

label_settings.setFormat(text_format)
neighborhoods.setLabelsEnabled(True)
neighborhoods.setLabeling(QgsVectorLayerSimpleLabeling(label_settings))

for lyr in [study_area, neighborhoods, roads, bus_route, bus_stops, schools, clinics, parks, service_buffers, transit_buffers, priority_gap]:
    lyr.triggerRepaint()

# Move map canvas to the study area if running inside QGIS desktop
try:
    canvas = iface.mapCanvas()
    canvas.setExtent(study_area.extent())
    canvas.refresh()
except Exception:
    pass

print("QGIS work sample loaded successfully.")
