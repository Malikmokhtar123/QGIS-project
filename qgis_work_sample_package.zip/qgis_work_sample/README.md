# QGIS Work Sample

## Project
**Public Service Accessibility and Transit Coverage**

This is a packaged QGIS-style work sample you can use as a portfolio piece.
It includes synthetic geospatial data, a PyQGIS loader script, a finished map preview,
a short PDF brief, and a CSV summary.

## What the sample shows
- Multi-layer GIS project organization
- Buffer analysis around schools, clinics, and bus stops
- Priority-gap identification with spatial overlay
- Neighborhood-level summary reporting
- Presentation-ready cartography

## Folder structure
- `data/` - GeoJSON layers for the project
- `scripts/load_qgis_sample.py` - load-and-style script for QGIS
- `outputs/accessibility_map.png` - finished map preview
- `outputs/project_brief.pdf` - short portfolio-style project summary
- `outputs/neighborhood_summary.csv` - neighborhood metrics

## Data layers
- `study_area.geojson`
- `neighborhoods.geojson`
- `roads.geojson`
- `bus_route.geojson`
- `bus_stops.geojson`
- `schools.geojson`
- `clinics.geojson`
- `parks.geojson`
- `service_buffers.geojson`
- `transit_buffers.geojson`
- `priority_gap.geojson`

## How to use it in QGIS
1. Open QGIS.
2. Open the Python Console.
3. Open the script editor inside the console.
4. Load `scripts/load_qgis_sample.py`.
5. Run the script.

The script loads the packaged GeoJSON layers, applies basic symbology, and zooms to the study area.

## Suggested portfolio description
This QGIS sample analyzes access to essential public services and transit in a synthetic study area near Denton, Texas. The workflow uses vector layer management, metric buffering, overlay analysis, service-gap extraction, and cartographic styling to identify neighborhoods with weaker access coverage.

## Notes
- The coordinates are spatially plausible, but the data are synthetic and safe to share publicly.
- You can extend this sample by adding census data, network routing, suitability scoring, or demographic equity analysis.
